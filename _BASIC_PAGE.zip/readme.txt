basic page structure with configured gulp. 
commend gulp watch running a server and you can see live changing on the page. You can also can work with sass file.